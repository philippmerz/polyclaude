# Polymarket consistency scan — 20261019T095940Z UTC

Coverage: **INCOMPLETE analysis (market_cap; 154 structural groups unquoted; 15 structural groups quote-failed)**. This is a volume-ranked ROI slice unless the keyset cursor was exhausted.

- filters: `{"closed": false, "end_date_max": "2027-01-05T23:59:59Z", "end_date_min": "2026-10-19T09:59:05Z", "exclude_tag_id": ["1"], "liquidity_min": null}`
- live quote selection: `balanced`; requested priority/exploration groups: {'priority': 10, 'exploration': 10}; legs: {'priority': 95, 'exploration': 78}; attempted groups/legs: 20/173; prior exact-history records: 152
- 31 pages / 34.7 MiB streamed; projected peak memory 62.3 MiB
- cursor_exhausted=false, stop_reason=market_cap, invalid_neg_risk_events=0

> **Coverage is incomplete. A zero below means no hit in the scanned slice; it is not a comprehensive exchange-wide zero.**

Universe slice: 5012 open markets scanned, 2945 validated neg-risk markets retained, 346 neg-risk groups, 268 midpoint-violations > 0.5%.

- **0 PROVISIONAL positive structural baskets (sequential CLOB depth; revalidation required)**
- 174 sum>1 (midpoint), 94 sum<1 (midpoint, directional)

> WARNING: gamma-api `outcomePrices` shows midpoints between stale stub bids (often $0.01) and real asks. Most midpoint-only "free arb" signals evaporate when orderbook asks are checked. Positive live-depth observations below are sequential and non-atomic: independently refresh every leg before any decision; this report is not an execution instruction.

## PROVISIONAL structural baskets (revalidation required)

Computed by walking CLOB asks for buy-all-NO of every member at one common size no smaller than any validated leg minimum. Reported economics are per basket unit; snapshots are sequential, not atomic. Profit assumes exactly one YES wins.

No positive provisional candidate in the scanned slice. Analysis is incomplete, so this is not a comprehensive zero.

## Midpoint-only sum>1 candidates (likely stale orderbooks)

Sorted by midpoint net edge. These are NOT executable; included for diagnostic only.

| Mid Edge | Live Edge | YES-sum | Members | Liquidity | Title |
|---:|---:|---:|---:|---:|---|
| +16.59% | no asks for market 5796553 | 2.4735 | 11 | $8,490 | Lowest temperature in Lucknow on October 19? |
| +15.70% | book validation failed for 5795311: CLOB book is stale (613.7s) | 2.4270 | 11 | $42,305 | Lowest temperature in Shenzhen on October 19? |
| +8.75% | no asks for market 5795267 | 1.8480 | 11 | $73,229 | Lowest temperature in Chongqing on October 19? |
| +6.86% | no asks for market 5795300 | 1.6730 | 11 | $38,409 | Lowest temperature in Chengdu on October 19? |
| +5.07% | book validation failed for 5798910: CLOB book is stale (500.9s) | 1.5300 | 11 | $5,896 | Lowest temperature in NYC on October 19? |
| +4.94% | book validation failed for 5795289: CLOB book is stale (1451.2s) | 1.5035 | 11 | $79,701 | Lowest temperature in Wuhan on October 19? |
| +4.85% | -5.74% | 1.2190 | 5 | $33,236 | Israel Election: Yisrael Beiteinu vote share? |
| +3.43% | -2.62% | 1.1665 | 5 | $1,236 | AutoZone Q1 domestic same store sales growth? |
| +3.39% | no asks for market 5795232 | 1.3475 | 11 | $19,284 | Lowest temperature in Madrid on October 19? |
| +3.37% | no asks for market 2495308 | 1.2670 | 8 | $18,925 | Nikkei 225: Close Price End of 2026 |
| +2.96% | live group cap | 1.3285 | 11 | $10,134 | Lowest temperature in Miami on October 19? |
| +2.72% | live group cap | 1.2795 | 11 | $106,632 | Lowest temperature in Beijing on October 19? |
| +2.59% | live group cap | 1.3145 | 12 | $4,749 | #2 AI lab by OpenRouter market share week of October 19? |
| +2.54% | live group cap | 1.4750 | 18 | $13,056 | Golden Joystick Awards: Ultimate Game of the Year Winner |
| +2.26% | live group cap | 1.2385 | 11 | $19,532 | Lowest temperature in Helsinki on October 19? |
| +2.11% | -4.41% | 1.1165 | 5 | $2,049 | Central Bank of Colombia decision in December |
| +1.82% | live group cap | 1.1920 | 11 | $13,941 | Lowest temperature in Karachi on October 19? |
| +1.66% | live group cap | 1.1850 | 10 | $63,995 | MO-07 House Election Margin of Victory |
| +1.61% | live group cap | 1.0940 | 5 | $1,573 | Procter & Gamble (PG) Q1 organic sales growth? |
| +1.28% | live group cap | 1.0950 | 6 | $47,219 | Israeli Legislative Election: Turnout |
| +1.24% | live group cap | 1.1255 | 8 | $4,361 | Argentina Monthly Inflation - October |
| +1.22% | live group cap | 1.1515 | 11 | $14,898 | Lowest temperature in Hong Kong on October 20? |
| +1.16% | live group cap | 1.1125 | 7 | $2,376 | #2 Free App in the US Apple App Store on October 23? |
| +1.15% | live group cap | 1.1595 | 11 | $5,593 | Ted Cruz # posts October 20 - October 27, 2026? |
| +1.11% | live group cap | 1.1545 | 11 | $14,113 | Highest temperature in Tokyo on October 21? |
| +1.05% | live group cap | 1.1315 | 10 | $95,754 | NC-08 House Election Margin of Victory |
| +1.02% | live group cap | 1.1050 | 7 | $3,633 | # of views of next MrBeast video on week 1? (Higher Brackets |
| +1.02% | live group cap | 1.1250 | 10 | $125,068 | California Governor Election: Turnout |
| +0.92% | live group cap | 1.0980 | 8 | $58,067 | Georgia Senate Election: Turnout (First Round) |
| +0.83% | live group cap | 1.0905 | 8 | $89,836 | NE-02 House Election Margin of Victory |

## Midpoint-only sum<1 candidates (directional, missing-mass risk)

| Mid Edge | YES-sum | Members | Liquidity | Title |
|---:|---:|---:|---:|---|
| +209.29% | 0.3140 | 6 | $77,611 | Who will Trump endorse for President of Brazil? |
| +49.00% | 0.6465 | 7 | $2,573 | Billboard Hot 100 #2 Song Week of October 31 |
| +36.90% | 0.7070 | 8 | $48,872 | Nevada Governor Election: Turnout |
| +26.54% | 0.7705 | 5 | $62,952 | Waterloo, ON Mayoral Election Winner |
| +8.28% | 0.9055 | 7 | $94,346 | Gambia Presidential Election Winner |
| +7.28% | 0.9255 | 21 | $19,914 | Which company has the best AI model on LiveBench (Overall) e |
| +6.95% | 0.9350 | 19 | $3,845,790 | Prime Minister of Israel after the next election? |
| +6.58% | 0.9110 | 5 | $1,767 | Visa (V) Q4 cross border volume total growth (constant dolla |
| +6.53% | 0.9260 | 7 | $25,665 | How many cities will Waymo operate in by December 31? |
| +6.51% | 0.9085 | 8 | $85,466 | Illinois Senate Election: Turnout |
| +6.20% | 0.9250 | 3 | $102,497 | Bitcoin vs. Gold vs. S&P 500 in 2026 |
| +6.03% | 0.9120 | 10 | $222,205 | Wisconsin Governor Election Margin of Victory |
| +4.67% | 0.9300 | 5 | $145,784 | Democratic nomination odds leader on October 31? |
| +4.54% | 0.9405 | 5 | $1,231 | Coca-Cola (KO) Q3 global unit case volume growth? |
| +4.15% | 0.9480 | 4 | $13,005 | Lowest Great Salt Lake elevation in 2026? |
